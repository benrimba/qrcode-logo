<?php 
	include"phpqrcode/qrlib.php";
	$buatFolder = "temp/";
	if (!file_exists($buatFolder)) {
		mkdir($buatFolder);
	}
	$logoPath = "logo.jpg";
	$Content = "Rudi Edukasi";
	QRcode::png($Content,$buatFolder.'qrwithlogo.jpg',QR_ECLEVEL_H,12,2);
	$QR = imagecreatefrompng($buatFolder.'qrwithlogo.jpg');
	$logo = imagecreatefromstring(file_get_contents($logoPath));
	imagecolortransparent($logo, imagecolorallocatealpha($logo, 0, 0, 0, 200));
	imagealphablending($logo, false);
	imagesavealpha($logo, true);
	$QR_width=imagesx($QR);
	$QR_height = imagesy($QR);
	$logo_width = imagesx($logo);
	$logo_height = imagesy($logo);
	$logo_qr_width = $QR_width/4;
	$scale = $logo_width/$logo_qr_width;
	$logo_qr_height = $logo_height/$scale;
	imagecopyresampled($QR,$logo,$QR_width/2.5,$QR_height/2.5, 0, 0, $logo_qr_width, $logo_qr_height, $logo_width, $logo_height);
	imagepng($QR,$buatFolder.'qrwithlogo.jpg');
	echo'<img src="'.$buatFolder.'qrwithlogo.jpg'.'"/>';
 ?>